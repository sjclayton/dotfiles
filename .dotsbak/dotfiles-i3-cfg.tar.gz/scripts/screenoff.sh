#!/bin/bash

sleep 2
xset s activate
